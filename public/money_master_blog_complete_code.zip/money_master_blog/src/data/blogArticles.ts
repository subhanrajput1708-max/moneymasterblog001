import { BlogArticle, BlogCategory, BlogArticleImage } from '../types';
import { ARTICLES_1_TO_5 } from './articles/article1To5';
import { ARTICLES_6_TO_10 } from './articles/article6To10';
import { ARTICLES_11_TO_15 } from './articles/article11To15';
import { ARTICLES_16_TO_20 } from './articles/article16To20';

export const BLOG_ARTICLES: BlogArticle[] = [
  ...ARTICLES_1_TO_5,
  ...ARTICLES_6_TO_10,
  ...ARTICLES_11_TO_15,
  ...ARTICLES_16_TO_20
];

export const BLOG_CATEGORIES: BlogCategory[] = [
  'Personal Loans',
  'Credit & Debt',
  'Savings & Budgeting',
  'Insurance & Auto',
  'Retirement & Goals'
];

export function getArticleImage(article: BlogArticle): BlogArticleImage {
  if (article.image) return article.image;
  switch (article.category) {
    case 'Personal Loans':
      return {
        src: '/images/personal-loans-guide.jpg',
        alt: `${article.title} - Personal Loan and Rate Analysis`,
        caption: `Practical loan analysis, APR calculation, and contract verification framework for ${article.title}.`
      };
    case 'Credit & Debt':
      return {
        src: '/images/credit-debt-guide.jpg',
        alt: `${article.title} - Credit Statement and Debt Payoff Management`,
        caption: `Actionable fee breakdown, statement auditing, and repayment roadmap for ${article.title}.`
      };
    case 'Savings & Budgeting':
      return {
        src: '/images/savings-budget-guide.jpg',
        alt: `${article.title} - High-Yield Savings and Budget Allocation`,
        caption: `Cash allocation rules, liquidity reserves, and compounding savings for ${article.title}.`
      };
    case 'Insurance & Auto':
      return {
        src: '/images/auto-insurance-guide.jpg',
        alt: `${article.title} - Auto Ownership and Insurance Policy Review`,
        caption: `Ownership cost breakdown, depreciation analysis, and policy clauses for ${article.title}.`
      };
    case 'Retirement & Goals':
      return {
        src: '/images/retirement-wealth-guide.jpg',
        alt: `${article.title} - Compound Interest and Long-Term Wealth Planning`,
        caption: `Compound growth modeling, timeline planning, and asset protection for ${article.title}.`
      };
    default:
      return {
        src: '/images/personal-loans-guide.jpg',
        alt: article.title,
        caption: `Practical financial framework for ${article.title}.`
      };
  }
}

export function getArticleBySlug(slug: string): BlogArticle | undefined {
  return BLOG_ARTICLES.find(article => article.slug === slug || article.id === slug);
}

export function getRecentArticles(count: number = 4): BlogArticle[] {
  return BLOG_ARTICLES.slice(0, count);
}

export function getRelatedArticles(currentSlug: string, count: number = 3): BlogArticle[] {
  const current = getArticleBySlug(currentSlug);
  if (!current) return BLOG_ARTICLES.slice(0, count);

  // Match same category first, excluding current article
  const sameCategory = BLOG_ARTICLES.filter(
    a => a.category === current.category && a.slug !== current.slug
  );

  if (sameCategory.length >= count) {
    return sameCategory.slice(0, count);
  }

  // If not enough in same category, supplement with others
  const others = BLOG_ARTICLES.filter(
    a => a.category !== current.category && a.slug !== current.slug
  );

  return [...sameCategory, ...others].slice(0, count);
}

export function getArticlesByCategory(category: BlogCategory | 'All'): BlogArticle[] {
  if (category === 'All') return BLOG_ARTICLES;
  return BLOG_ARTICLES.filter(article => article.category === category);
}

export function searchArticles(query: string, category: BlogCategory | 'All' = 'All'): BlogArticle[] {
  const cleanQuery = query.toLowerCase().trim();
  let baseArticles = category === 'All' ? BLOG_ARTICLES : getArticlesByCategory(category);

  if (!cleanQuery) return baseArticles;

  return baseArticles.filter(article => {
    return (
      article.title.toLowerCase().includes(cleanQuery) ||
      article.excerpt.toLowerCase().includes(cleanQuery) ||
      article.quickAnswer.toLowerCase().includes(cleanQuery) ||
      article.category.toLowerCase().includes(cleanQuery) ||
      article.sections.some(s => 
        s.heading.toLowerCase().includes(cleanQuery) ||
        s.paragraphs.some(p => p.toLowerCase().includes(cleanQuery))
      )
    );
  });
}
